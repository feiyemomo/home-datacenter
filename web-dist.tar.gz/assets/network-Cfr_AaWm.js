import{c as a,W as p,Y as r,i as f}from"./index-Dms-cp8l.js";import{j as k}from"./vendor-react-1B7PQhyt.js";/**
 * @license lucide-react v0.451.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=a("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.451.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=a("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]]);/**
 * @license lucide-react v0.451.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=a("Gauge",[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]]);/**
 * @license lucide-react v0.451.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=a("UserPlus",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]]);async function C(){const{data:t}=await r.get("/vision/status");return t}async function D(){const{data:t}=await r.get("/vision/persons");return t??[]}async function m(t,e){const{data:n}=await r.post("/vision/persons",{name:t,image:e});return n}async function S(t){const{data:e}=await r.delete(`/vision/persons/${encodeURIComponent(t)}`);return e}async function U(t,e){const n=p(),c={};n&&(c.Authorization=`Bearer ${n}`);const o=await fetch(e,{headers:c});if(!o.ok)throw new Error(`无法获取快照图像 (HTTP ${o.status})`);const d=await o.blob(),u=await new Promise((h,y)=>{const s=new FileReader;s.onloadend=()=>{const i=s.result,l=i.includes(",")?i.split(",")[1]:i;h(l)},s.onerror=y,s.readAsDataURL(d)});return m(t,u)}function j({className:t}){return k.jsx("div",{className:f("shimmer rounded-xl bg-[rgb(var(--bg-subtle))]",t),"aria-hidden":"true"})}const w="nas.feiyemomo.top";function g(){if(typeof window>"u")return"remote";const t=window.location.hostname;return t==="localhost"||t==="127.0.0.1"||t.startsWith("192.168.")||t.startsWith("10.")||/^172\.(1[6-9]|2[0-9]|3[01])\./.test(t)?"lan":t===w||/^\[[0-9a-f:]+\]$/i.test(t)?"ipv6":"remote"}function R(){return g()==="remote"}export{b as C,P as G,j as S,A as U,M as a,S as b,m as c,g as d,C as g,R as i,D as l,U as r};
